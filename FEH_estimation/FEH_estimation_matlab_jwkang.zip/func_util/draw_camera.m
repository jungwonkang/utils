%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% draw camera
% H         : pose wrt world frame (homogeneous transform)
% scale     : scale
% axislabel : axis label
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function draw_camera(H, h_img, w_img, k_mat, colorstyle_cam, scale, axislabel, filled)

%%%%%%%% set virtual normalized image plane
% h_img = 480;
% w_img = 640;
% 
% k_mat = [300    0   w_img/2;
%          0    300   h_img/2;
%          0      0       1];
     
pnt_img = [ 0    (w_img-1)      (w_img-1)       0          0;
            0       0           (h_img-1)   (h_img-1)      0;
            1       1               1           1          1];
%          p1      p2              p3          p4         p1
%
%                        p2
%        p1 ----------------> x (image plane)
%           |
%           |
%        p4 |            p3
%           v
%           y        
    % pnt_img : point on image plane

%%%% get points on normalized image plane
pnt_img_nip = inv(k_mat)*pnt_img;   
    % pnt_img_nip: point on normalized image plane

%%%% scaling
pnt_img_nip = pnt_img_nip*scale;    
pnt_ip      = [pnt_img_nip; zeros(3,5); pnt_img_nip];    
pnt_ip_set  = reshape(pnt_ip, 3, 15);
    

%%%%%%%% set axis
pnt_axis = [0       1       0       0       0       0;
            0       0       0       1       0       0;
            0       0       0       0       0       1];
%         origin    X     origin    Y     origin    Z   
        
pnt_axis = pnt_axis*scale;


%%%%%%%% move coordinate
rot   = H(1:3,1:3);
trans = H(1:3,4);

pnt_ip_set2 = rot*pnt_ip_set + trans*ones(1,15);
pnt_axis2   = rot*pnt_axis   + trans*ones(1,6);

pnt_text_ori  = [pnt_axis(1,2)*0.15; pnt_axis(2,4)*0.15; -pnt_axis(3,6)*0.15];
pnt_text_ori2 = rot*pnt_text_ori + trans;


%%%%%%%% draw

%%%% axis
hold on;
plot3(pnt_axis2(1,:), pnt_axis2(2,:), pnt_axis2(3,:),'b-','linewidth', 1');

text(pnt_axis2(1,2), pnt_axis2(2,2), pnt_axis2(3,2), 'X_c');
text(pnt_axis2(1,4), pnt_axis2(2,4), pnt_axis2(3,4), 'Y_c');
text(pnt_axis2(1,6), pnt_axis2(2,6), pnt_axis2(3,6), 'Z_c');
text(pnt_text_ori2(1), pnt_text_ori2(2), pnt_text_ori2(3), axislabel);


%%%% camera
if filled == 1,
    p2 = struct('vertices',pnt_ip_set2','faces',[1 10 7;7 4 1]);
    h2 = patch(p2);
    set(h2,'facecolor',[247 239 7]/255,'EdgeColor', 'none');           
end

plot3(pnt_ip_set2(1,:), pnt_ip_set2(2,:), pnt_ip_set2(3,:), colorstyle_cam, 'linewidth', 2);
hold off;




































    
    

