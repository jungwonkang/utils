%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% draw feature
% pnt  : 3 x N
% scale: N x 1
% color: N x 3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function draw_feature(pnt, scale, color, b_label)

hold on;
    scatter3(pnt(1,:), pnt(2,:), pnt(3,:), scale, color, 'filled', 'MarkerEdgeColor', [0 0 0]);

    if b_label == 1,
        text_offset = 0.2;    

        for i=1:size(pnt,2),
            tx = num2str(i);
            text(pnt(1,i)+text_offset, pnt(2,i)+text_offset, pnt(3,i)+text_offset, tx);
        end
    end
hold off;

% for i=1:length(P(1,:)),
%     tx=strcat(num2str(i));
%     text(P(1,i)+m,P(2,i)+m,P(3,i)+m,tx,'Color',col);
% end;


% r(:), g(:), b(:), s, c, 'filled');
% 
% if true,
%     r = img_in(:,:,1);  % r: h_img x w_img
%     g = img_in(:,:,2);  % g: h_img x w_img
%     b = img_in(:,:,3);  % b: h_img x w_img
% 
%     s = 5.*ones(length(r(:)), 1);
%     c = [r(:)/255, g(:)/255, b(:)/255];
% 
%     figure,
%     axis([0 255 0 255 0 255]); 
%     axis equal;
%     hold on;
%     %scatter3(r(:), g(:), b(:), s, c, 'filled');
%     plot3
%     grid on;
%     title('data samples (overall image)');
%     xlabel('R');
%     ylabel('G');
%     zlabel('B');
%     hold off;
% end


