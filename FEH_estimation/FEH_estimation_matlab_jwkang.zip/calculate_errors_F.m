%%%% calculate_errors
% 2012/8/29(��)
% ������
function err_out = calculate_errors_F(F, z1_set, z2_set, h_img, w_img, fh1, fh2, b_show_img, b_show_point_dist, b_show_point_transfer, type_dist)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [�����]
%   (1) F              : fundamental matrix
%   (2) z1_set, z2_set : image coordinate
%           z1_set, z2_set: 3 x M
%           z2_set'*F*z1_set = 0
%   (3) type_dist      : distance type 
%                       1 - symmetric transfer distance
%                       2 - reprojection distance
% [���]
%   (1) show measurement points and their corresponding points
%   (2) calculate errors
%   (3) b_show_img
%       b_show_img_cp  : distance ����� ���� ������ display flag
%       b_show_img_epl : epipolar line
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


fprintf(1, 'calculate_errors_F...\n');


%%%%%%%% caption
caption1 = 'Input image 1 with corresponding points (F)';
caption2 = 'Input image 2 with corresponding points (F)';


%%%%%%%% get info
totnum_pnts = size(z1_set, 2);


%%%%%%%% input image
if b_show_img == true, 
    img1 = uint8( 255.*ones(h_img, w_img, 3) );
    img2 = uint8( 255.*ones(h_img, w_img, 3) );
end


%%%%%%%% calculate distance
z1c_set = zeros(2, totnum_pnts);   % zXc_set : distance ����� ���� corresponding points
z2c_set = zeros(2, totnum_pnts);

err_sum = 0;

for i=1:totnum_pnts,
    z1        = z1_set(:,i);    % [x y] of image 1
    z2        = z2_set(:,i);    % [x y] of image 2

    err_alg   = z2'*F*z1;       % algebraic error
        
    F_z1      = F*z1;
    F_z1_1    = F_z1(1);
    F_z1_2    = F_z1(2);

    FT_z2     = F'*z2;
    FT_z2_1   = FT_z2(1);
    FT_z2_2   = FT_z2(2);

    if type_dist == 1, 
        %%%% symmetric epipolar distance
        J1           = [FT_z2_1,  FT_z2_2];         % J1: 1 x 2 for d(x, F(T)x')^2
        J2           = [F_z1_1,   F_z1_2];          % J2: 1 x 2 for d(x', Fx)^2
        
        err_this     = ( err_alg^2 )*( 1/(F_z1_1^2 + F_z1_2^2) + 1/(FT_z2_1^2 + FT_z2_2^2) );  % err_this : d^2
        
        dz1          = -J1'*err_alg/(J1*(J1'));     % dz1: 2 x 1
        dz2          = -J2'*err_alg/(J2*(J2'));     % dz2: 2 x 1                
    else
        %%%% reprojection distance
        err_this     = ( err_alg^2 )/( F_z1_1^2 + F_z1_2^2 + FT_z2_1^2 + FT_z2_2^2 );          % err_this : d^2
        
        J            = [FT_z2_1^2, FT_z2_2^2, F_z1_1^2, F_z1_2^2];      % J: 1 x 4
        
        dz           = -( err_alg/(J*(J')) )*J';    % dz: 4 x 1        
        dz1          = [dz(1) dz(2)]';
        dz2          = [dz(3) dz(4)]';
    end                    

    % corresponding point for calculating distance
    z1c_set(:,i) = z1(1:2) + dz1;    % for measurement of image 1
    z2c_set(:,i) = z2(1:2) + dz2;    % for measurement of image 2
    
    err_sum      = err_sum + err_this;
end

% mean error (average of d^2)
err_out = err_sum/totnum_pnts;


%%%%%%% show img1
if b_show_img == true,
    figure(fh1);
        set(gcf,'color',[1 1 1]);
        cla;
        image(img1);
        title(caption1);    
        hold on;

        for i=1:totnum_pnts,        
            %%%% draw measurement (point & feature id)
            % +1 �� matlab �ε��� ��ȯ ������.
            plot(z1_set(1,i) + 1, z1_set(2,i) + 1, 'o', 'MarkerFaceColor', 'c', 'MarkerSize', 5);                                                     
            text(z1_set(1,i) + 5, z1_set(2,i) - 7, num2str(i), 'color', 'c' );

            %%%% draw corresponding point for calculating distance (point & feature id)
            if b_show_point_dist == true,
                plot(z1c_set(1,i) + 1, z1c_set(2,i) + 1, 'o', 'MarkerFaceColor', 'b', 'MarkerSize', 5);
                text(z1c_set(1,i) + 5, z1c_set(2,i) - 7, num2str(i), 'color', 'b' );
            end
            
            %%%% draw epipolar lines
            if b_show_point_transfer == true,
                [x_vec_ep, y_vec_ep] = calculate_vec_epline_on_img1(F, z2_set(1,i), z2_set(2,i), h_img, w_img);

                if length(y_vec_ep) ~= 2 || length(x_vec_ep) ~= 2, 
                    fprintf(1, 'Warning: can not draw epipolar line on img1...\n');
                else
                    plot(x_vec_ep, y_vec_ep, 'r');
                    text(x_vec_ep(1), y_vec_ep(1), num2str(i), 'color', 'r' );
                end
            end
        end

        hold off;
end    
    

%%%%%%% show img2
if b_show_img == true,
    figure(fh2);
        set(gcf,'color',[1 1 1]);
        cla;
        image(img2);
        title(caption2);
        hold on;

        for i=1:totnum_pnts,
            %%%% draw measurement (point & feature id)
            % +1 �� matlab �ε��� ��ȯ ������.
            plot(z2_set(1,i) + 1, z2_set(2,i) + 1, 'o', 'MarkerFaceColor', 'c', 'MarkerSize', 5);                                                            
            text(z2_set(1,i) + 5, z2_set(2,i) - 7, num2str(i), 'color', 'c' );

            %%%% draw corresponding point for calculating distance (point & feature id)
            if b_show_point_dist == true,
                plot(z2c_set(1,i) + 1, z2c_set(2,i) + 1, 'o', 'MarkerFaceColor', 'b', 'MarkerSize', 5);
                text(z2c_set(1,i) + 5, z2c_set(2,i) - 7, num2str(i), 'color', 'b' );
            end
            
            %%%% draw epipolar lines
            if b_show_point_transfer == true,
                [x_vec_ep, y_vec_ep] = calculate_vec_epline_on_img2(F, z1_set(1,i), z1_set(2,i), h_img, w_img);
            
                if length(y_vec_ep) ~= 2 || length(x_vec_ep) ~= 2, 
                    fprintf(1, 'Warning: can not draw epipolar line on img2...\n');
                else
                    plot(x_vec_ep, y_vec_ep, 'r');
                    text(x_vec_ep(1), y_vec_ep(1), num2str(i), 'color', 'r' );
                end
            end
        end

        hold off;
end
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [x_vec_ep, y_vec_ep] = calculate_vec_epline_on_img1(F, x2, y2, h_img, w_img)
% image 2�� measurement�� �����ϴ� image 1������ epipolar line�� �׸�.

%%%% get epipolar line info
L1 = F'*[x2; y2; 1];

A  = L1(1);
B  = L1(2);
C  = L1(3);


%%%% ���� point ����
y_vec = [];
x_vec = [];

if (A == 0) || (B == 0),
    if A == 0,
        y1 = -C/B;      x1 = 0;
        y2 = -C/B;      x2 = w_img-1;
    end

    if B == 0,
        y1 = 0;         x1 = -C/A;
        y2 = h_img-1;   x2 = -C/A;
    end

    y_vec = [y1+1, y2+1];   % matlab �ε��� ��ȯ
    x_vec = [x1+1, x2+1];        
else
    x1 = 0;             y1 = -(A/B)*x1 - (C/B);
    x2 = w_img-1;       y2 = -(A/B)*x2 - (C/B);    
    y3 = 0;             x3 = -(B/A)*y3 - (C/A);
    y4 = h_img-1;       x4 = -(B/A)*y4 - (C/A);

    if (0<=y1)&&(y1<=(h_img-1)),
        y = y1 + 1;
        x = x1 + 1;
        y_vec = [y_vec y];
        x_vec = [x_vec x];        
    end

    if (0<=y2)&&(y2<=(h_img-1)),
        y = y2 + 1;
        x = x2 + 1;
        y_vec = [y_vec y];
        x_vec = [x_vec x];
    end

    if (0<=x3)&&(x3<=(w_img-1)),
        y = y3 + 1;
        x = x3 + 1;
        y_vec = [y_vec y];
        x_vec = [x_vec x];        
    end

    if (0<=x4)&&(x4<=(w_img-1)),
        y = y4 + 1;
        x = x4 + 1;
        y_vec = [y_vec y];
        x_vec = [x_vec x];        
    end            
end


y_vec_ep = y_vec;
x_vec_ep = x_vec;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [x_vec_ep, y_vec_ep] = calculate_vec_epline_on_img2(F, x1, y1, h_img, w_img)
% image 1�� measurement�� �����ϴ� image 2������ epipolar line�� �׸�.



%%%% get epipolar line info
L1 = F*[x1; y1; 1];

A = L1(1);
B = L1(2);
C = L1(3);


%%%% ���� point ����
y_vec = [];
x_vec = [];

if (A == 0) || (B == 0),
    if A == 0,
        y1 = -C/B;      x1 = 0;
        y2 = -C/B;      x2 = w_img-1;
    end

    if B == 0,
        y1 = 0;         x1 = -C/A;
        y2 = h_img-1;   x2 = -C/A;
    end

    y_vec = [y1+1, y2+1];   % matlab �ε��� ��ȯ
    x_vec = [x1+1, x2+1];        
else
    y_vec = [];    
    x_vec = [];

    x1 = 0;             y1 = -(A/B)*x1 - (C/B);
    x2 = w_img-1;       y2 = -(A/B)*x2 - (C/B);    
    y3 = 0;             x3 = -(B/A)*y3 - (C/A);
    y4 = h_img-1;       x4 = -(B/A)*y4 - (C/A);

    
    if (0<=y1)&&(y1<=(h_img-1)),
        y = y1 + 1;
        x = x1 + 1;
        y_vec = [y_vec y];
        x_vec = [x_vec x];        
    end

    if (0<=y2)&&(y2<=(h_img-1)),
        y = y2 + 1;
        x = x2 + 1;
        y_vec = [y_vec y];
        x_vec = [x_vec x];
    end

    if (0<=x3)&&(x3<=(w_img-1)),
        y = y3 + 1;
        x = x3 + 1;
        y_vec = [y_vec y];
        x_vec = [x_vec x];        
    end

    if (0<=x4)&&(x4<=(w_img-1)),
        y = y4 + 1;
        x = x4 + 1;
        y_vec = [y_vec y];
        x_vec = [x_vec x];        
    end            
end        


y_vec_ep = y_vec;
x_vec_ep = x_vec;


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    