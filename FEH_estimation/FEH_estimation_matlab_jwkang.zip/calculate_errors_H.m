%%%% calculate_errors
% 2012/8/29(��)
% ������
function err_out = calculate_errors_H(H, z1_set, z2_set, h_img, w_img, fh1, fh2, b_show_img, b_show_point_dist, b_show_point_transfer, type_dist)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [�����]
%   (1) H              : homography
%   (2) z2_set, z1_set : image coordinate
%           z2_set, z1_set: 3 x M
%           z2_set = H*z1_set
%   (3) type_dist      : distance type 
%                       1 - symmetric transfer distance
%                       2 - reprojection distance
% [���]
%   (1) show measurement points and their corresponding points
%   (2) calculate errors
%   (3) b_show_img
%       b_show_img_cp   : distance ����� ���� ������ display flag
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


fprintf(1, 'calculate_errors_H...\n');


%%%%%%%% caption
caption1 = 'Input image 1 with corresponding points (H)';
caption2 = 'Input image 2 with corresponding points (H)';


%%%%%%%% get info
totnum_pnts = size(z1_set, 2);

inv_H       = inv(H);
h11 = H(1,1);   h12 = H(1,2);   h13 = H(1,3);
h21 = H(2,1);   h22 = H(2,2);   h23 = H(2,3);
h31 = H(3,1);   h32 = H(3,2);   h33 = H(3,3);


%%%%%%%% input image
if b_show_img == true, 
    img1 = uint8( 255.*ones(h_img, w_img, 3) );
    img2 = uint8( 255.*ones(h_img, w_img, 3) );
end


%%%%%%%% calculate distance
z1c_set = zeros(2, totnum_pnts);
z2c_set = zeros(2, totnum_pnts);

err_sum = 0;

for i=1:totnum_pnts,
    z1 = z1_set(:,i);       % [x y] of image 1
    z2 = z2_set(:,i);       % [x y] of image 2
         
    if type_dist == 1, 
        %%%% symmetric transfer distance
        z1c          = inv_H*z2;
        x1c          = z1c(1)/z1c(3);
        y1c          = z1c(2)/z1c(3);
        z1c_set(1,i) = x1c;
        z1c_set(2,i) = y1c;
        
        z2c          = H*z1;
        x2c          = z2c(1)/z2c(3);
        y2c          = z2c(2)/z2c(3);
        z2c_set(1,i) = x2c;
        z2c_set(2,i) = y2c;        
        
        err_this = (z1(1) - x1c)^2 + (z1(2) - y1c)^2 + (z2(1) - x2c)^2 + (z2(2) - y2c)^2;
    else
        %%%% reprojection distance
        j11 =  h11 - h31*z2(1);
        j12 =  h12 - h32*z2(1);
        j13 = -h31*z1(1) - h32*z1(2) - h33;
        j14 =  0;
        
        j21 =  h21 - h31*z2(2);
        j22 =  h22 - h32*z2(2);
        j23 =  0;
        j24 = -h31*z1(1) - h32*z1(2) - h33;
        
        J   = [j11 j12 j13 j14;
               j21 j22 j23 j24;];
           
        e1  = h11*z1(1) + h12*z1(2) + h13 - h31*z1(1)*z2(1) - h32*z1(2)*z2(1) - h33*z2(1);
        e2  = h21*z1(1) + h22*z1(2) + h23 - h31*z1(1)*z2(2) - h32*z1(2)*z2(2) - h33*z2(2);         
        e   = [e1 e2]';
        
        dz  = -J'*inv(J*J')*e;      % dz: 4 x 1
        
        err_this = dz'*dz;
        
        z1c_set(1,i) = z1(1) + dz(1);
        z1c_set(2,i) = z1(2) + dz(2);
        
        z2c_set(1,i) = z2(1) + dz(3);
        z2c_set(2,i) = z2(2) + dz(4);
    end
    
    err_sum  = err_sum + err_this;
end

% mean error (average of d^2)
err_out = err_sum/totnum_pnts;    



%%%%%%% show img1
if b_show_img == true,
    figure(fh1);
        set(gcf,'color',[1 1 1]);
        cla;
        image(img1);
        title(caption1);    
        hold on;

        for i=1:totnum_pnts,
            %%%% draw measurement (point & feature id)
            % +1 �� matlab �ε��� ��ȯ ������.
            plot(z1_set(1,i) + 1, z1_set(2,i) + 1, 'o', 'MarkerFaceColor', 'c', 'MarkerSize', 5);                        
            text(z1_set(1,i) + 5, z1_set(2,i) - 7, num2str(i), 'color', 'c' );

            %%%% draw corresponding point for calculating distance (point & feature id)
            if b_show_point_dist == true,
                plot(z1c_set(1,i) + 1, z1c_set(2,i) + 1, 'o', 'MarkerFaceColor', 'b', 'MarkerSize', 5);
                text(z1c_set(1,i) + 5, z1c_set(2,i) - 7, num2str(i), 'color', 'b' );
            end
            
            %%%% draw transferred point 
            if b_show_point_transfer == true && type_dist == 2,
                z1t  = inv_H*z2_set(:,i);
                x1t  = z1t(1)/z1t(3);
                y1t  = z1t(2)/z1t(3);
                
                plot(x1t + 1, y1t + 1, 'o', 'MarkerFaceColor', 'r', 'MarkerSize', 5);
                text(x1t + 5, y1t - 7, num2str(i), 'color', 'r' );                                                
            end
        end

        hold off;
end

    
%%%%%%% show img2
if b_show_img == true,
    figure(fh2);
        set(gcf,'color',[1 1 1]);
        cla;
        image(img2);
        title(caption2);
        hold on;

        for i=1:totnum_pnts,
            %%%% draw measurement (point & feature id)
            % +1 �� matlab �ε��� ��ȯ ������.
            plot(z2_set(1,i) + 1, z2_set(2,i) + 1, 'o', 'MarkerFaceColor', 'c', 'MarkerSize', 5);                
            text(z2_set(1,i) + 5, z2_set(2,i) - 7, num2str(i), 'color', 'c' );

            %%%% corresponding point for calculating distance
            if b_show_point_dist == true,
                plot(z2c_set(1,i) + 1, z2c_set(2,i) + 1, 'o', 'MarkerFaceColor', 'b', 'MarkerSize', 5);
                text(z2c_set(1,i) + 5, z2c_set(2,i) - 7, num2str(i), 'color', 'b' );
            end
            
            %%%% draw transferred point 
            if b_show_point_transfer == true && type_dist == 2,
                z2t  = H*z1_set(:,i);
                x2t  = z2t(1)/z2t(3);
                y2t  = z2t(2)/z2t(3);
                
                plot(x2t + 1, y2t + 1, 'o', 'MarkerFaceColor', 'r', 'MarkerSize', 5);
                text(x2t + 5, y2t - 7, num2str(i), 'color', 'r' );                                                
            end            
        end

        hold off;
end    
    
 
    
    
    