% camera simulator, Jungwon Kang, KAIST
% 1st started at Oct 14, 2009
% 2nd revised at Aug 23, 2012
% 3rd revised at Nov 15, 2013


clc;
clear all;
close all;


addpath('.\\func_FEH\\common');
addpath('.\\func_FEH\\E5');
addpath('.\\func_FEH\\E8');
addpath('.\\func_FEH\\F7');
addpath('.\\func_FEH\\F8');
addpath('.\\func_FEH\\H');
addpath('.\\func_util');



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% setting intrinsic & extrinsic parameters for cameras
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% K, intrinsic property
H_img = 480;
W_img = 640;
Fsx   = 300;
Fsy   = 300;
Cx    = W_img/2;
Cy    = H_img/2;

K_mat = [Fsx    0      Cx;
          0    Fsy     Cy;
          0     0       1];
      
%%%% H1 - cam pose before motion (wrt world frame)
%R1_true = eye(3);
R1_true = rotoz(pi/36)*rotoy(-pi/36)*rotox(-pi/36);
T1_true = [0 0 0]';
H1_true = [R1_true T1_true; zeros(1,3), 1];

%%%% delta motion
%dR = rotoz(0)*rotoy(0)*rotox(0);
%dR = rotoz(0)*rotoy(-pi/9)*rotox(0);
dR = eye(3);
%dT = [0.2; 0; 0];
dT = [0; 0; 0];
dH = [dR dT; zeros(1,3), 1];

%%%% H2 - cam pose after motion
H2_true = H1_true*dH;
R2_true = H2_true(1:3,1:3);
T2_true = H2_true(1:3,4);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% setting features
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% feature position
%X_feature = [ -1, -1,  1,  1, -1, -1,  1,  1 ];
%Y_feature = [ -1,  1, -1,  1, -1,  1, -1,  1 ];
%Z_feature = [  3,  3,  3,  3,  6,  6,  6,  6 ];
%X_feature = [ -1.5, -1,  1,  1 ];
%Y_feature = [ -1,  1, -1.5,  1 ];
%Z_feature = [ 6,  6,  6,  6 ];

%%%% 5 point (plane)
%X_feature = [ -1,  1,  1, -1.5,  1.5 ];
%Y_feature = [ -1, -1,  1,  1.5, -1.5 ];
%Z_feature = [  5,  5,  5,    5,    5 ];

%%%% 5 point
%X_feature = [ -1.50, -1.30,  1.60,  1.25,  1.30];
%Y_feature = [ -1.20,  1.42, -1.62,  1.46, -1.17];
%Z_feature = [  3.10,  4.20,  4.70,  2.50,  7.20];

%%%% 8 point (plane)
X_feature = [ -1, -1,  1,  1, -1.5, -1.5,  1.5,  1.5 ];
Y_feature = [ -1,  1, -1,  1, -1.5,  1.5, -1.5,  1.5 ];
Z_feature = [  5,  5,  5,  5,    5,    5,    5,    5 ];

%%%% 8 point
%X_feature = [ -1.50, -1.30,  1.60,  1.25, -1.80, -1.20,  1.30,  1.55 ];
%Y_feature = [ -1.20,  1.42, -1.62,  1.46, -1.87,  1.24, -1.17,  1.82 ];
%Z_feature = [  3.10,  4.20,  4.70,  2.50,  5.12,  5.70,  7.20,  8.20 ];

%%%% 7 point
%X_feature = [ -1.50, -1.30,  1.60,  1.25, -1.80, -1.20,  1.30];
%Y_feature = [ -1.20,  1.42, -1.62,  1.46, -1.87,  1.24, -1.17];
%Z_feature = [  3.10,  4.20,  4.70,  2.50,  5.12,  5.70,  7.20];

%%%% 7 point
%X_feature = [ -1.50, -1.30,  1.60,  1.25, -1.80, -1.20, 1.55 ];
%Y_feature = [ -1.20,  1.42, -1.62,  1.46, -1.87,  1.24, 1.82 ];
%Z_feature = [  3.10,  4.20,  4.70,  2.50,  5.12,  5.70, 8.20 ];


P_feature = [X_feature; Y_feature; Z_feature];      % P_feature : 3 x n



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% E, F (true)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% E (true), E = [t]xR
R21 = R2_true'*R1_true;
T21 = R2_true'*(T1_true - T2_true);
T21_hat = [0         -T21(3)        T21(2);
           T21(3)     0            -T21(1);
          -T21(2)     T21(1)       0];
E_true = T21_hat*R21;

%%%% F (true), F = K^(-T)*E*K^(-1)
F_true = inv(K_mat)'*E_true*inv(K_mat);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% draw camera & feature
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% setting
fh_main1       = 10;
    scale_cam        = 0.5;
    axis_label1      = 'cam1';
    axis_label2      = 'cam2';
    
fh_main2       = 11;
    size_worldframe  = 0.5;
    size_cameraframe = 0.5;
    size_camera      = 0.5;


%%%% draw camera & feature
if true, 
    figure(fh_main1), 
        rotate3d on;
        cla(fh_main1);
        grid on;
        axis([-5 5 -5 5 0 10]);  
        axis equal;    
        set(gcf,'color',[1 1 1]);
        xlabel('X(world)');
        ylabel('Y(world)');
        zlabel('Z(world)');

        % draw camera 1
        hold on;    
            draw_camera(H1_true, H_img, W_img, K_mat, 'c-', scale_cam, axis_label1, 0);

        % draw camera 2
        hold on;
            draw_camera(H2_true, H_img, W_img, K_mat, 'b-', scale_cam, axis_label2, 0);

        % draw feature
            draw_feature(P_feature, 30,  [0.1 0.9 1.0],  1);
        hold off;
end
 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% make measurement
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% set handles
fh_mea1 = 20;
fh_mea2 = 21;

%%%% make measurement
[id_feature1, z_img1] = make_inputimage(P_feature, 'c', K_mat, H1_true, H_img, W_img, 'Input image 1', fh_mea1, false);
[id_feature2, z_img2] = make_inputimage(P_feature, 'c', K_mat, H2_true, H_img, W_img, 'Input image 2', fh_mea2, false);
    % z_imgX : 3 x M
    
%%%% check occlusion
num_feature_real = size(P_feature, 2);
num_feature1     = length(id_feature1);
num_feature2     = length(id_feature2);

if (num_feature_real ~= num_feature1) || (num_feature_real ~= num_feature2),
    fprintf(1, 'Error: features are occlueded...\n');
    return;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 1. Estimate E (5 point algorithm, Henrik Stewenius-kang)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if false,
    fprintf('[E5] estimating E using 5 point algorithm\n');

    [E_out, F_out, num_EF] = estimate_essential_matrix_5pnts_kang(z_img1(:,1:5), z_img2(:,1:5), K_mat, true);
    
    num_EF
    F = F_out(:,:,2)
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 2. Estimate E (8 point algorithm, MASKS-kang)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if false,
    fprintf('[E8] estimating E using 8 point algorithm\n');
    
    [E_out, F_out, T0, R0] = dessential_kang(z_img1, z_img2, K_mat, true);
    
    F = F_out;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 3. Estimate F (7 point algorithm, MVG-kang)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if false,
    fprintf('[F7] estimating F using 7 point algorithm\n');
    
    [F_out, num_F] = vgg_F_from_7pts_2img_kang(z_img1(:,2:8), z_img2(:,2:8), true);
    
    for i=1:num_F,
        fprintf(1, '[%d]th F\n', i);
        F_out(:,:,i)
    end
    
    num_F
    F = F_out(:,:,3);
    %F = F_out(:,:,3);
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 4. Estimate F (8 point algorithm, MVG-kang)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if true, 
    fprintf('[F8] estimating F using 8 point algorithm\n');
    
    [F] = fundmatrix_kang(z_img1, z_img2, true);
    F
    
    %for n = 1:7, disp(norm(z_mea2(:,n)'*F*z_mea1(:,n))), end    
    %E1 = K_mat'*F*K_mat; 
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 5. Estimate H (MVG2-kang)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if false, 
    fprintf('[H] estimating H\n');

    H = homography2d_kang(z_img1, z_img2, true);
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% draw measurement & correspondence
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% set handles
fh_img1_ep = 30;
fh_img2_ep = 31;


%%%% draw correspondence
%make_inputimage1_with_Eline100(F, z_mea2, P_feature, K_mat, R1_true, T1_true, H_img, W_img, fh_img1_ep);
%make_inputimage2_with_Eline100(F, z_mea1, P_feature, K_mat, R2_true, T2_true, H_img, W_img, fh_img2_ep);
%make_inputimage1_with_Eline100(F_true, z_mea2, P_feature, K_mat, R1_true, T1_true, H_img, W_img, fh_img1_ep);
%make_inputimage2_with_Eline100(F_true, z_mea1, P_feature, K_mat, R2_true, T2_true, H_img, W_img, fh_img2_ep);


%%%% set handles
fh_img1_hp = 40;
fh_img2_hp = 41;

%%%% draw correspondence
%make_inputimage1_with_Hpoint100(H, z_mea2, P_feature, K_mat, R1_true, T1_true, H_img, W_img, fh_img1_hp);
%make_inputimage2_with_Hpoint100(H, z_mea1, P_feature, K_mat, R2_true, T2_true, H_img, W_img, fh_img2_hp);

%%%% draw correspondence
%make_inputimage1_with_epipolar_lines100(E1, z_mea2, P_feature, K_mat, R1_true, T1_true, H_img, W_img, fh_img1_ep);
%make_inputimage2_with_epipolar_lines100(E1, z_mea1, P_feature, K_mat, R2_true, T2_true, H_img, W_img, fh_img2_ep);


%%%% set handles
fh_img1_err_F = 50;
fh_img2_err_F = 51;
fh_img1_err_H = 60;
fh_img2_err_H = 61;

err_F = calculate_errors_F(F, z_img1, z_img2, H_img, W_img, fh_img1_err_F, fh_img2_err_F, true, false, true, 2)
%err_H = calculate_errors_H(H, z_img1, z_img2, H_img, W_img, fh_img1_err_H, fh_img2_err_H, true, true, true, 2)



































