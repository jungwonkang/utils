%%%% make an input image
function [id_feature, z_mea] = make_inputimage(P_feature, color, k_mat, H_cam, h_img, w_img, caption, handle_figure, b_show_img)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [input]
%   P_feature     : 3D feature position, 3 x n
%   k_mat         : K matrix, 3x3
%   H_cam         : camera position, homogeneous transformation form, (wrt world frame), 4x4
%   h_img, w_img  : image size
%   caption       : caption
%   handle_figure : figure handle, just number
% [output]
%   id_feature  : index of features in FOV, in the image, (1 x M)
%   z_mea        : measurement(x_img, y_img, 1) in the homogeneous coordinate (3 x M)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% distance threshold
dist_thres = 1000000;

%%%% number of features
num_features = size(P_feature, 2);

%%%% set rotation, translation
rot_cam   = H_cam(1:3, 1:3);
trans_cam = H_cam(1:3, 4);

%%%% input image
if b_show_img == true,
    img_in = uint8( 255.*ones(h_img, w_img, 3) );
end

%%% show
if b_show_img == true,
    figure_handle = figure(handle_figure);
        set(gcf,'color',[1 1 1]);
        cla;
        image(img_in);
        hold on;
end

%%%% initialize output
id_feature = [];
z_mea      = [];


if num_features >= 1,
    for i=1:num_features,
        %%%% get 3D feature position
        xf = P_feature(1,i);
        yf = P_feature(2,i);
        zf = P_feature(3,i);
        pf = [xf; yf; zf; 1];

        %%%% distance threshold
        pose_cam = [trans_cam; 1];
        dist = norm(pf - pose_cam);

        if dist < dist_thres,

                %%%% form a projection matrix
                p_mat    = k_mat*[rot_cam', -rot_cam'*trans_cam];
                pnt_mea  = p_mat*pf;
                %pnt_mea = k_mat*rot_cam'*(pf - trans_cam);

                x_mea = pnt_mea(1)/pnt_mea(3);        
                y_mea = pnt_mea(2)/pnt_mea(3);
                %[y_mea, x_mea]

                %x_mea = x_mea + randn(1);
                %y_mea = y_mea + randn(1);

                %x_mea = floor( x_mea );
                %y_mea = floor( y_mea );

                %%%% if it is in the image region
                if (0 <= y_mea) && (y_mea < h_img) && (0 <= x_mea) && (x_mea < w_img),

                        %%%% checking depth, MVG p.162
                        depth_gauge = det( p_mat(1:3, 1:3) )*pnt_mea(3);

                        if depth_gauge > 0      % only points with positive depth are valid 

                                % save output
                                id_feature = [id_feature i];          % index of feature
                                mea        = [x_mea; y_mea; 1];        % measurement of the feature
                                z_mea      = [z_mea mea];              

                                if b_show_img == true,
                                    % draw point
                                    plot(x_mea+1, y_mea+1, 'o', 'MarkerFaceColor', color, 'MarkerSize', 5);
                                        % +1 �� matlab �ε��� ��ȯ ������.

                                    % insert feature id
                                    text(x_mea+5, y_mea-7, num2str(i), 'color', 'k' );
                                end
                        end
                end
        end
    end
end

if b_show_img == true,
    hold off;

    % add title
    title(caption);
end



