% 2012/8/30(��)
% ������
% calibrated_fivepoint.m�� wrapper
function [E_out, F_out, num_EF] = estimate_essential_matrix_5pnts_kang(x1, x2, k_mat, b_show_debug)
% x1, x2 : 3 x M 

fprintf(1, 'estimating E using 5 point algorithm..\n');

if size(x1, 2) ~= 5,
    fprintf(1, 'Wrong size of input data. It should be 5.\n');
    E_out  = [];
    F_out  = [];
    num_EF = 0;
    return;
end

%%%% get image points on normalized image plane
x1_nip = inv(k_mat)*x1;
x2_nip = inv(k_mat)*x2;


%%%% get distributed normalized measurement
[x1n_nip, T1] = normalise2dpts(x1_nip);
[x2n_nip, T2] = normalise2dpts(x2_nip);


%%%% estimate E, F
E_set_info = calibrated_fivepoint(x1n_nip, x2n_nip);

E_out  = [];
F_out  = [];
num_EF = 0;

for i=1:size(E_set_info, 2),
    E_this = reshape(E_set_info(:,i), 3, 3)';
    
    if b_show_debug == true,         
        fprintf(1, '[%d]th essential matrix..\n', i);
        fprintf(1, 'estimated E\n');
            E_this

        fprintf(1, 'checking det constraint\n');
            det(E_this)

        fprintf(1, 'checking trace constraint\n');
            2*E_this*E_this'*E_this - trace(E_this*E_this')*E_this

        fprintf(1, 'checking reprojection errors');
            diag(x2n_nip'*E_this*x1n_nip)
    end
    
    E_this_out = T2'*E_this*T1;
    F_this_out = inv(k_mat)'*E_this_out*inv(k_mat);
    
    num_EF = num_EF + 1;
    E_out = cat(3, E_out, E_this_out);
    F_out = cat(3, F_out, F_this_out);
end

















