
clc;
clear all;
close all;

% %% original script
% Q1 = rand(3,5);
% Q2 = rand(3,5);
% Evec   = calibrated_fivepoint( Q1,Q2);
% for i=1:size(Evec,2)
%     disp('---------')
%     
%   E = reshape(Evec(:,i),3,3);
%   % Check determinant constraint! 
%   det( E)
%   % Check trace constraint
%   2 *E*transpose(E)*E -trace( E*transpose(E))*E
%   % Check reprojection errors
%   diag( Q1'*E*Q2)
% end

%% transfromed script
Q1 = randn(3,5);
Q2 = randn(3,5);
Q1(3, :) = 1;
Q2(3, :) = 1;

Q1
Q2


Evec   = calibrated_fivepoint( Q1,Q2);
for i=1:size(Evec,2)
    disp('---------')
    
  E = reshape(Evec(:,i),3,3);
  % Check determinant constraint! 
  det( E)
  % Check trace constraint
  2 *E*transpose(E)*E -trace( E*transpose(E))*E
  % Check reprojection errors
  diag( Q1'*E*Q2)
end