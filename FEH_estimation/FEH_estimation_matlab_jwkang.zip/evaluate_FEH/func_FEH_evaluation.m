% 2012/8/30(��)
% ������

function [err_F_dist1, ...
          err_F_dist2, ...
          err_H_dist1, ...
          err_H_dist2] = func_FEH_evaluation(H_cam1, H_cam2, K_mat, H_img, W_img, P_feature, type_alg_F, type_alg_H)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [�Է�]
%   (1) camera position 
%   (2) scene structure 
%   (3) �˰����� ����
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% draw camera & feature
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% setting
fh_main1       = 10;
    scale_cam        = 0.5;
    axis_label1      = 'cam1';
    axis_label2      = 'cam2';
    
fh_main2       = 11;
    size_worldframe  = 0.5;
    size_cameraframe = 0.5;
    size_camera      = 0.5;

%%%% draw camera & feature 1 (new style)
if true, 
    figure(fh_main1), 
        rotate3d on;
        cla(fh_main1);
        grid on;
        axis([-5 5 -5 5 0 10]);  
        axis equal;    
        set(gcf,'color',[1 1 1]);
        xlabel('X(world)');
        ylabel('Y(world)');
        zlabel('Z(world)');

        % draw camera 1
        hold on;    
            draw_camera(H_cam1, H_img, W_img, K_mat, 'c-', scale_cam, axis_label1, 0);

        % draw camera 2
        hold on;
            draw_camera(H_cam2, H_img, W_img, K_mat, 'b-', scale_cam, axis_label2, 0);

        % draw feature
            draw_feature(P_feature, 30,  [0.1 0.9 1.0],  1);
        hold off;
end
   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% make measurement
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% set handles
fh_mea1 = 20;
fh_mea2 = 21;

%%%% make measurement
[id_feature1, z_img1] = make_inputimage(P_feature, 'c', K_mat, H_cam1, H_img, W_img, 'Input image 1', fh_mea1, false);
[id_feature2, z_img2] = make_inputimage(P_feature, 'c', K_mat, H_cam2, H_img, W_img, 'Input image 2', fh_mea2, false);
    % z_imgX : 3 x M
    
%%%% check occlusion
num_feature_real = size(P_feature, 2);
num_feature1     = length(id_feature1);
num_feature2     = length(id_feature2);

if (num_feature_real ~= num_feature1) || (num_feature_real ~= num_feature2),
    fprintf(1, 'Error: features are occlueded...\n');
    return;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 1. Estimate E (5 point algorithm, Henrik Stewenius-kang)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if type_alg_F == 10,
    fprintf('[E5] estimating E using 5 point algorithm\n');

    [E_out, F_out, num_EF] = estimate_essential_matrix_5pnts_kang(z_img1, z_img2, K_mat, true);
    
    F = F_out(:,:,1);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 2. Estimate E (8 point algorithm, MASKS-kang)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if type_alg_F == 11,
    fprintf('[E8] estimating E using 8 point algorithm\n');
    
    %%%% estimate E
    [E_out, F_out, T0, R0] = dessential_kang(z_img1, z_img2, K_mat, true);
    
    F = F_out;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 3. Estimate F (7 point algorithm, MVG-kang)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if type_alg_F == 20,
    fprintf('[F7] estimating F using 7 point algorithm\n');
    
    [F_out, num_F] = vgg_F_from_7pts_2img_kang(z_img1, z_img2, true);
    
    for i=1:num_F,
        fprintf(1, '[%d]th F\n', i);
        F_out(:,:,i)
    end
    
    F = F_out(:,:,1);
    %F = F_out(:,:,3);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 4. Estimate F (8 point algorithm, MVG-kang)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if type_alg_F == 22,
    fprintf('[F8] estimating F using 8 point algorithm\n');

    %%%% estimate F
    [F] = fundmatrix_kang(z_img1, z_img2, true);
    F
    
    %for n = 1:7, disp(norm(z_mea2(:,n)'*F*z_mea1(:,n))), end    
    %E1 = K_mat'*F*K_mat; 
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 5. Estimate H (MVG2-kang)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if type_alg_H == 32,
    fprintf('[H] estimating H\n');

    %%%% esimate H
    H = homography2d_kang(z_img1, z_img2, true);
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% draw measurement & correspondence
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% set handles
fh_img1_err_F = 30;
fh_img2_err_F = 31;
fh_img1_err_H = 40;
fh_img2_err_H = 41;

err_F_dist1 = calculate_errors_F(F, z_img1, z_img2, H_img, W_img, fh_img1_err_F, fh_img2_err_F, true, true, true, 1);
err_F_dist2 = calculate_errors_F(F, z_img1, z_img2, H_img, W_img, fh_img1_err_F, fh_img2_err_F, true, true, true, 2);

err_H_dist1 = calculate_errors_H(H, z_img1, z_img2, H_img, W_img, fh_img1_err_H, fh_img2_err_H, true, true, true, 1);
err_H_dist2 = calculate_errors_H(H, z_img1, z_img2, H_img, W_img, fh_img1_err_H, fh_img2_err_H, true, true, true, 2);
































