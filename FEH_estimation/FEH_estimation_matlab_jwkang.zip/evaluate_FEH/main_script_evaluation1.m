% camera simulator, Jungwon Kang, KAIST
% 1st started at Oct 14, 2009
% 2nd revised at Aug 23, 2012
% 3rd revised at Nov 15, 2013


clc;
clear all;
close all;


addpath('..\\');
addpath('..\\func_FEH\\common');
addpath('..\\func_FEH\\E5');
addpath('..\\func_FEH\\E8');
addpath('..\\func_FEH\\F7');
addpath('..\\func_FEH\\F8');
addpath('..\\func_FEH\\H');
addpath('..\\func_util');



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% setting - camera
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% K, intrinsic property
H_img = 480;
W_img = 640;
Fsx   = 300;
Fsy   = 300;
Cx    = W_img/2;
Cy    = H_img/2;

K_mat = [Fsx    0      Cx;
          0    Fsy     Cy;
          0     0       1];
      
     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% setting - test
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
type_test = 11;
    % type_test = 10: F(5pt) vs H
    %       with fixed general structure
    % type_test = 11: F(7pt) vs H
    %       with fixed general structure
    % type_test = 20: F(5pt) vs H
    %       with structure varying plane to non-plane
    % type_test = 21: F(7pt) vs H
    %       with structure varying plane to non-plane
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% setting - algorithm type
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if type_test == 10,
    type_alg_F = 10;
    type_alg_H = 32;
    str_title  = 'E(5pt) vs H with varying camera motion, fixed general structure';
    str_xlabel = 'Translation in X(m)';
end

if type_test == 11,
    type_alg_F = 20;
    type_alg_H = 32;
    str_title  = 'F(7pt) vs H with varying camera motion, fixed general structure';
    str_xlabel = 'Translation in X(m)';
end

if type_test == 20,
    type_alg_F = 10;
    type_alg_H = 32;
    str_title  = 'E(5pt) vs H with fixed camera motion, varying structure';
    str_xlabel = 'Variation in structure';
end

if type_test == 21,
    type_alg_F = 20;
    type_alg_H = 32;
    str_title  = 'F(7pt) vs H with fixed camera motion, varying structure';
    str_xlabel = 'Variation in structure';
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% setting - feature
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if type_test == 10, 
    %%%% 5 point (general structure)
    X_feature = [ -1.50, -1.30,  1.60,  1.25,  1.30 ];
    Y_feature = [ -1.20,  1.42, -1.62,  1.46, -1.17 ];
    Z_feature = [  3.10,  4.20,  4.70,  2.50,  7.20 ];
end

if type_test == 11,
    %%%% 7 point (general structure)
    X_feature = [ -1.50, -1.30,  1.60,  1.25, -1.80, -1.20,  1.30 ];
    Y_feature = [ -1.20,  1.42, -1.62,  1.46, -1.87,  1.24, -1.17 ];
    Z_feature = [  3.10,  4.20,  4.70,  2.50,  5.12,  5.70,  7.20 ];
end

if type_test == 20,
    %%%% 5 point (plane)
    X_feature = [ -1,  1,  1, -1.5,  1.5 ];
    Y_feature = [ -1, -1,  1,  1.5, -1.5 ];
    Z_feature = [  5,  5,  5,    5,    5 ];
end

if type_test == 21,
    %%%% 7 point (plane)
    X_feature = [ -1, -1,  1,  1, -1.5, -1.5,  1.5 ];
    Y_feature = [ -1,  1, -1,  1, -1.5,  1.5, -1.5 ];
    Z_feature = [  5,  5,  5,  5,    5,    5,    5 ];
end

P_feature_ori = [X_feature; Y_feature; Z_feature];      % P_feature : 3 x n

%%%% factor for making non-plane
dsx7 = [-1.0722    1.4367   -1.2078    1.3790   -0.2725    2.0015   -0.8236];
dsy7 = [ 0.9610   -1.9609    2.1080   -1.0582    1.0984    0.7518    1.5771];
dsz7 = [-1.1240   -0.6977    1.8252   -0.4686   -0.2779   -0.3538    0.5080];
ds7  = [dsx7; dsy7; dsz7];

dsx5 = [-1.0722             -1.2078    1.3790              2.0015   -0.8236];
dsy5 = [ 0.9610              2.1080   -1.0582              0.7518    1.5771];
dsz5 = [-1.1240              1.8252   -0.4686             -0.3538    0.5080];
ds5  = [dsx5; dsy5; dsz5];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% ready
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
step_s = 1;
step_e = 11;

% allocate
arr_x           = zeros(1, step_e - step_s + 1);
arr_err_F_dist1 = zeros(1, step_e - step_s + 1);
arr_err_F_dist2 = zeros(1, step_e - step_s + 1);
arr_err_H_dist1 = zeros(1, step_e - step_s + 1);
arr_err_H_dist2 = zeros(1, step_e - step_s + 1);


%%%%%%%% main loop for test
for step = step_s:step_e,
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%% setting camera motion
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%% H1 - cam pose before motion (wrt world frame)
    R1_true = eye(3);
    %R1_true = rotoz(pi/8)*rotoy(-pi/9)*rotox(-pi/9);
    T1_true = [0 0 0]';
    H1_true = [R1_true T1_true; zeros(1,3), 1];

    %%%% delta motion
    if type_test == 10 || type_test == 11, 
        % test with varying camera motion, fixed general structure
        dR = rotoz(0)*rotoy(-pi/9)*rotox(0);
        dX = (step - 1)*0.1
        dT = [dX; 0; 0];    
        dH = [dR dT; zeros(1,3), 1];
    else
        % test with fixed camera motion, varying structure
        dR = rotoz(0)*rotoy(-pi/9)*rotox(0);
        dX = 0.5;
        dT = [dX; 0; 0];    
        dH = [dR dT; zeros(1,3), 1];        
    end
        
    %%%% H2 - cam pose after motion
    H2_true = H1_true*dH;
    R2_true = H2_true(1:3,1:3);
    T2_true = H2_true(1:3,4);

    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%% setting structure
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    P_feature = P_feature_ori;
    
    if type_test == 20,
        % test with 5 points
        dP = ds5*(step - 1)*0.1;
        P_feature = P_feature + dP;
    end
    
    if type_test == 21, 
        % test with 7 points
        dP = ds7*(step - 1)*0.1;
        P_feature = P_feature + dP;
    end
    
    
    %%%% estimate
    [err_F_dist1, ...
     err_F_dist2, ...
     err_H_dist1, ...
     err_H_dist2] = func_FEH_evaluation(H1_true, H2_true, K_mat, H_img, W_img, P_feature, type_alg_F, type_alg_H);

 
    %%%% save
    arr_x          (step) = (step - 1)*0.1;        
    arr_err_F_dist1(step) = err_F_dist1;
    arr_err_F_dist2(step) = err_F_dist2;
    arr_err_H_dist1(step) = err_H_dist1;
    arr_err_H_dist2(step) = err_H_dist2;    
end



figure(100),
    str_ylabel  = 'Error(pixel^2)';
    
    str_alg1    = 'F - symmetric epipolar error';
    str_alg2    = 'F - reprojection error';
    str_alg3    = 'H - symmetric epipolar error';
    str_alg4    = 'H - reprojection error';

    hold on;    plot(arr_x, arr_err_F_dist1, '-r*', 'LineWidth', 1, 'MarkerSize', 4, 'MarkerFaceColor', 'r');   hold off;
    hold on;    plot(arr_x, arr_err_F_dist2, '-rs', 'LineWidth', 1, 'MarkerSize', 4, 'MarkerFaceColor', 'r');   hold off;
    hold on;    plot(arr_x, arr_err_H_dist1, '-b*', 'LineWidth', 1, 'MarkerSize', 4, 'MarkerFaceColor', 'b');   hold off;
    hold on;    plot(arr_x, arr_err_H_dist2, '-bs', 'LineWidth', 1, 'MarkerSize', 4, 'MarkerFaceColor', 'b');   hold off;

    set(gca, 'XGrid', 'off', 'YGrid', 'on', 'GridLineStyle', '-');
    legend(str_alg1, str_alg2, str_alg3, str_alg4, 'Location', 'NorthWest');

    %xlim([1 length(x_data)]);
    %ylim([0 1]);
    
    xlabel(str_xlabel);
    ylabel(str_ylabel);
    title(str_title);


